(function () {
  function track(name, properties) {
    if (typeof window.track === 'function') {
      window.track(name, properties || {});
    }
  }

  function initialiseProjectCheck(root) {
    if (!root || root.dataset.projectCheckInitialised === 'true') return;
    root.dataset.projectCheckInitialised = 'true';

    var destination = 'checkout';
    var continueButton = root.querySelector('[data-project-check-continue]');
    var cartAddUrl = root.dataset.cartAddUrl || '/cart/add.js';
    var checkoutUrl = root.dataset.checkoutUrl || '/checkout';

    if (continueButton) {
      continueButton.href = checkoutUrl;
      continueButton.textContent = 'Checkout Securely';

      continueButton.addEventListener('click', function () {
        track('fl_project_check_continue', {
          destination: destination
        });
      });
    }

    track('fl_project_check_view', {
      destination: destination
    });

    function refreshThemeCart() {
      document.dispatchEvent(new CustomEvent('cart:build'));
    }

    if (document.documentElement.dataset.projectCheckDrawerRefreshBound !== 'true') {
      document.documentElement.dataset.projectCheckDrawerRefreshBound = 'true';
      document.addEventListener('CartDrawer:open', refreshThemeCart);
    }

    root.addEventListener('click', function (event) {
      var decreaseButton = event.target.closest('[data-project-check-decrease]');
      var increaseButton = event.target.closest('[data-project-check-increase]');
      var stepperButton = decreaseButton || increaseButton;
      if (!stepperButton) return;

      var form = stepperButton.closest('[data-project-check-form]');
      var quantityInput = form ? form.querySelector('[name="quantity"]') : null;
      var quantityValue = form ? form.querySelector('[data-project-check-quantity-value]') : null;
      var formDecreaseButton = form ? form.querySelector('[data-project-check-decrease]') : null;
      if (!quantityInput || !quantityValue) return;

      var currentQuantity = Math.max(1, parseInt(quantityInput.value, 10) || 1);
      var nextQuantity = increaseButton
        ? currentQuantity + 1
        : Math.max(1, currentQuantity - 1);

      quantityInput.value = nextQuantity;
      quantityValue.textContent = nextQuantity;

      if (formDecreaseButton) {
        formDecreaseButton.disabled = nextQuantity === 1;
      }
    });

    root.addEventListener('submit', function (event) {
      var form = event.target.closest('[data-project-check-form]');
      if (!form) return;

      event.preventDefault();

      var button = form.querySelector('[data-project-check-add]');
      var errorElement = form.querySelector('[data-project-check-error]');
      var card = form.closest('[data-project-check-card]');
      var variantInput = form.querySelector('[name="id"]');
      var quantityInput = form.querySelector('[name="quantity"]');
      var quantity = Math.max(1, parseInt(quantityInput.value, 10) || 1);

      if (!button || button.disabled || !variantInput) return;

      button.disabled = true;
      button.classList.add('btn--loading');
      errorElement.hidden = true;
      errorElement.textContent = '';

      fetch(cartAddUrl, {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify({
          id: Number(variantInput.value),
          quantity: quantity
        })
      })
        .then(function (response) {
          return response.json().then(function (data) {
            if (!response.ok || data.status) {
              throw new Error(data.description || 'This item could not be added.');
            }

            return data;
          });
        })
        .then(function (product) {
          var itemListName = card ? card.dataset.itemListName : 'Project Check';
          var itemListId = card ? card.dataset.itemListId : 'project-check';
          var position = card ? card.dataset.position : '';
          var productId = card ? card.dataset.productId : product.product_id;
          var productTitle = card ? card.dataset.productTitle : product.title;
          var unitPrice = product.price ? product.price / 100 : undefined;

          button.classList.remove('btn--loading');
          button.textContent = '✓ Added';

          refreshThemeCart();

          track('fl_project_check_add', {
            product_id: productId,
            variant_id: variantInput.value,
            product_title: productTitle,
            quantity: quantity,
            destination: destination,
            position: position,
            item_list_name: itemListName,
            item_list_id: itemListId,
            value: unitPrice !== undefined ? unitPrice * quantity : undefined,
            currency: 'GBP',
            items: [{
              item_id: productId || product.id || '',
              item_name: productTitle || '',
              item_variant: variantInput.value,
              item_list_name: itemListName,
              item_list_id: itemListId,
              index: position,
              price: unitPrice,
              quantity: quantity
            }]
          });

          window.setTimeout(function () {
            button.textContent = 'Add to Order';
            button.disabled = false;
          }, 1600);
        })
        .catch(function (error) {
          button.classList.remove('btn--loading');
          button.disabled = false;
          errorElement.textContent = error.message;
          errorElement.hidden = false;
        });
    });
  }

  function initialiseAll() {
    document.querySelectorAll('[data-project-check]').forEach(initialiseProjectCheck);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialiseAll);
  } else {
    initialiseAll();
  }

  document.addEventListener('shopify:section:load', function () {
    initialiseAll();
  });
})();
