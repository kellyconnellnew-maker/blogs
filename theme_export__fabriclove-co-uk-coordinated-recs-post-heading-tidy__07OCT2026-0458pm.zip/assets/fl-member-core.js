/* ===========================
   Fabric Love - Member Core
   - Global member verification layer
   - Prospect (welcome discount) + Member states
   - Omnisend form submit detection
   - Rolling persistence
   - Omnisend campaign session detection
   - Popup success/subscribed routing
   - Applies active member discount codes globally
   - Applies prospect welcome discount (MEMBER10)
   - Member always overrides Prospect
   - Uses window.FL_OFFERS as single source of truth
   - Supports force-applying specific offer codes from PDP
   - Dispatches UI refresh events
   =========================== */

(function () {
  const CONFIG = window.FL_MEMBER_CONFIG || {};
  const PERSIST_DAYS = Number(CONFIG.persistDays || 30);
  const PROSPECT_PERSIST_DAYS = Number(CONFIG.prospectPersistDays || 7);
  const WELCOME_DISCOUNT_CODE = String(CONFIG.welcomeDiscountCode || 'MEMBER10').trim().toUpperCase();
  const EXCLUDED_POPUP_FORM_IDS = Array.isArray(CONFIG.excludedPopupFormIds) ? CONFIG.excludedPopupFormIds : [];
  const EXCLUDED_EMBEDDED_FORM_IDS = Array.isArray(CONFIG.excludedEmbeddedFormIds) ? CONFIG.excludedEmbeddedFormIds : [];
  const MEMBER_SIGNIN_FORM_IDS = Array.isArray(CONFIG.memberSignInFormIds) ? CONFIG.memberSignInFormIds : [];
  const MEMBER_ACTIVATION_FORM_IDS = Array.isArray(CONFIG.memberActivationFormIds) ? CONFIG.memberActivationFormIds : [];
  const DEBUG = !!CONFIG.debug;
  const MEMBER_SESSION_URL_PARAM = String(CONFIG.memberSessionUrlParam || 'fl_member').trim();
  const MEMBER_SESSION_URL_VALUE = String(CONFIG.memberSessionUrlValue || '1').trim();
    const PROSPECT_SESSION_URL_PARAM = String(CONFIG.prospectSessionUrlParam || 'fl_prospect').trim();
  const PROSPECT_SESSION_URL_VALUE = String(CONFIG.prospectSessionUrlValue || '1').trim();
  const STORAGE_KEYS = {
    memberSession: 'fl_member_session',
    memberPersistTs: 'fl_member_persist_ts',
    memberLastSource: 'fl_member_last_source',
    lastVerifiedEventTs: 'fl_member_verified_event_ts',

    prospectSession: 'fl_prospect_session',
    prospectPersistTs: 'fl_prospect_persist_ts',
    prospectLastSource: 'fl_prospect_last_source',
    prospectDiscountApplied: 'fl_prospect_discount_applied_' + WELCOME_DISCOUNT_CODE
  };

  function log() {
    if (!DEBUG) return;
    try {
      console.log.apply(console, ['[FL Member]'].concat([].slice.call(arguments)));
    } catch (e) {}
  }

  function ssGet(key) {
    try { return sessionStorage.getItem(key); } catch (e) { return null; }
  }

  function ssSet(key, value) {
    try { sessionStorage.setItem(key, value); } catch (e) {}
  }

  function ssRemove(key) {
    try { sessionStorage.removeItem(key); } catch (e) {}
  }

  function lsGet(key) {
    try { return localStorage.getItem(key); } catch (e) { return null; }
  }

  function lsSet(key, value) {
    try { localStorage.setItem(key, value); } catch (e) {}
  }

  function lsRemove(key) {
    try { localStorage.removeItem(key); } catch (e) {}
  }

window.track = function(eventName, params) {
  params = params || {};
  try {
    if (typeof window.gtag === 'function') {
      window.gtag('event', eventName, params);
    }

    window.dataLayer = window.dataLayer || [];
    window.dataLayer.push({
      event: eventName,
      ...params
    });

    console.log('TRACK', eventName, params);

  } catch(e) {}
};

  function nowTs() {
    return Date.now();
  }

  function memberPersistValid() {
    const ts = parseInt(lsGet(STORAGE_KEYS.memberPersistTs), 10);
    if (!ts) return false;
    const ttl = PERSIST_DAYS * 24 * 60 * 60 * 1000;
    return (nowTs() - ts) < ttl;
  }

  function prospectPersistValid() {
    const ts = parseInt(lsGet(STORAGE_KEYS.prospectPersistTs), 10);
    if (!ts) return false;
    const ttl = PROSPECT_PERSIST_DAYS * 24 * 60 * 60 * 1000;
    return (nowTs() - ts) < ttl;
  }

  function hasKnownMemberHistory() {
    return !!(
      lsGet(STORAGE_KEYS.memberPersistTs) ||
      lsGet(STORAGE_KEYS.memberLastSource)
    );
  }

  function hasMemberSession() {
    return ssGet(STORAGE_KEYS.memberSession) === '1';
  }

  function hasProspectSession() {
    return ssGet(STORAGE_KEYS.prospectSession) === '1';
  }

  function isVerifiedMember() {
    return hasMemberSession() || memberPersistValid();
  }

  function isVerifiedProspect() {
    return !isVerifiedMember() && (hasProspectSession() || prospectPersistValid());
  }

  function isExpiredKnownMember() {
    return hasKnownMemberHistory() && !isVerifiedMember();
  }

  function clearProspectState() {
    ssRemove(STORAGE_KEYS.prospectSession);
    lsRemove(STORAGE_KEYS.prospectPersistTs);
    lsRemove(STORAGE_KEYS.prospectLastSource);
    ssRemove(STORAGE_KEYS.prospectDiscountApplied);
    log('Prospect state cleared');
  }

  function getRenderedOfferNodes() {
    return Array.from(document.querySelectorAll('[data-fl-member-offer][data-discount-code]'));
  }

  function getRenderedOfferCodes() {
    return getRenderedOfferNodes()
      .map(function (node) {
        return String(node.getAttribute('data-discount-code') || '').trim().toUpperCase();
      })
      .filter(Boolean)
      .filter(function (value, index, arr) {
        return arr.indexOf(value) === index;
      });
  }

  function getAllActiveMemberCodes() {
    if (!Array.isArray(window.FL_OFFERS)) {
      log('window.FL_OFFERS is not available yet.');
      return [];
    }

    return window.FL_OFFERS
      .filter(function (offer) {
        return offer && offer.enabled && offer.code;
      })
      .map(function (offer) {
        return String(offer.code || '').trim().toUpperCase();
      })
      .filter(Boolean)
      .filter(function (value, index, arr) {
        return arr.indexOf(value) === index;
      });
  }

  async function applyDiscountCode(code) {
    const url = '/discount/' + encodeURIComponent(code) + '?redirect=/';
    const response = await fetch(url, {
      method: 'GET',
      credentials: 'same-origin',
      cache: 'no-store'
    });

    if (!response.ok) {
      throw new Error('Discount request failed with status ' + response.status);
    }
  }

  async function clearDiscountCodes() {
    const root = window.Shopify && window.Shopify.routes && window.Shopify.routes.root
      ? window.Shopify.routes.root
      : '/';
    const url = root.replace(/\/$/, '') + '/cart/update.js';
    const response = await fetch(url, {
      method: 'POST',
      credentials: 'same-origin',
      cache: 'no-store',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({ discount: '' })
    });

    if (!response.ok) {
      throw new Error('Discount clear-down failed with status ' + response.status);
    }

    return response.json();
  }

  function refreshCartUI() {
    try {
      document.dispatchEvent(new Event('cart:refresh'));
      document.dispatchEvent(new Event('cart:updated'));
      document.dispatchEvent(new Event('cart:change'));

      fetch('/cart.js', {
        credentials: 'same-origin',
        cache: 'no-store'
      }).then(function () {
        document.dispatchEvent(new Event('cart:refresh'));
        document.dispatchEvent(new Event('cart:updated'));
        document.dispatchEvent(new Event('cart:change'));
      }).catch(function () {});
    } catch (e) {}
  }

  let memberDiscountQueue = Promise.resolve();

  async function reconcileMemberDiscountCodes(codes, options) {
    options = options || {};
    const force = !!options.force;
    const clearExisting = !!options.clearExisting;

    const normalizedCodes = (Array.isArray(codes) ? codes : [])
      .map(function (code) {
        return String(code || '').trim().toUpperCase();
      })
      .filter(Boolean)
      .filter(function (value, index, arr) {
        return arr.indexOf(value) === index;
      });

    if (!normalizedCodes.length) {
      log('No discount codes supplied for applyDiscountCodes().');
      return;
    }

    const codesToApply = force
      ? normalizedCodes
      : normalizedCodes.filter(function (code) {
          return ssGet('fl_member_discount_applied_' + code) !== '1';
        });

    if (!codesToApply.length) {
      log('All requested discount codes already applied this session.');
      return;
    }

    log(
      force ? 'Force applying member discount codes:' : 'Applying member discount codes:',
      codesToApply
    );

    // Only a full member-identification batch may clear retained Shopify
    // discounts. Product-page force calls must never clear the cart because
    // they contain only the codes relevant to that product.
    if (clearExisting) {
      await clearDiscountCodes();
    }

    for (const code of codesToApply) {
      try {
        await applyDiscountCode(code);
        ssSet('fl_member_discount_applied_' + code, '1');
        await new Promise(function (resolve) { setTimeout(resolve, 75); });
      } catch (e) {
        console.error('[FL Member] Failed to apply discount code:', code, e);
      }
    }

    setTimeout(refreshCartUI, 150);
  }

  function applyDiscountCodes(codes, options) {
    // Member verification and product-page rendering can request discounts at
    // the same time. Serialize the batches so a second clear-down cannot run
    // midway through the first batch's applications.
    const run = function () {
      return reconcileMemberDiscountCodes(codes, options);
    };

    memberDiscountQueue = memberDiscountQueue.then(run, run);
    return memberDiscountQueue;
  }

  async function applyRelevantMemberDiscounts() {
    const codes = getAllActiveMemberCodes();

    if (!codes.length) {
      log('No active member discount codes found.');
      return;
    }

    await applyDiscountCodes(codes, { force: false, clearExisting: true });
  }

  async function applyProspectDiscount(options) {
    options = options || {};
    const force = !!options.force;

    if (!WELCOME_DISCOUNT_CODE) return;
    if (isVerifiedMember()) {
      log('Skipping prospect discount because member state is active.');
      return;
    }

    if (!force && ssGet(STORAGE_KEYS.prospectDiscountApplied) === '1') {
      log('Prospect discount already applied this session.');
      return;
    }

    try {
      log(force ? 'Force applying prospect discount:' : 'Applying prospect discount:', WELCOME_DISCOUNT_CODE);
      await applyDiscountCode(WELCOME_DISCOUNT_CODE);
      ssSet(STORAGE_KEYS.prospectDiscountApplied, '1');
      setTimeout(refreshCartUI, 150);
    } catch (e) {
      console.error('[FL Member] Failed to apply prospect discount:', WELCOME_DISCOUNT_CODE, e);
    }
  }

  async function forceApplyCodes(codes) {
    await applyDiscountCodes(codes, { force: true });
  }

  function broadcastMemberStateChanged(source) {
    const detail = {
      verified: true,
      source: source || 'unknown'
    };

    window.dispatchEvent(new CustomEvent('fl_member_state_changed', { detail: detail }));
  }

  function broadcastProspectStateChanged(source) {
    const detail = {
      verified: true,
      source: source || 'unknown'
    };

    window.dispatchEvent(new CustomEvent('fl_prospect_state_changed', { detail: detail }));
  }

  let verifyInFlight = false;
  let prospectVerifyInFlight = false;

  async function markMemberVerified(source, options) {
    options = options || {};
    if (verifyInFlight) return;

    verifyInFlight = true;

    try {
      // Member always overrides Prospect
      clearProspectState();

      const ts = String(nowTs());

      ssSet(STORAGE_KEYS.memberSession, '1');
      lsSet(STORAGE_KEYS.memberPersistTs, ts);
      lsSet(STORAGE_KEYS.memberLastSource, source || 'unknown');
      ssSet(STORAGE_KEYS.lastVerifiedEventTs, ts);

      log('Member verified from source:', source);

      if (!options.skipTrack) {
        track('fl_member_verified', {
          source: source || 'unknown',
          page_path: location.pathname
        });
      }

      broadcastMemberStateChanged(source || 'unknown');
      await applyRelevantMemberDiscounts();
         setTimeout(refreshCartUI, 250);
    } finally {
      verifyInFlight = false;
    }
  }

  async function markProspectVerified(source, options) {
    options = options || {};
    if (prospectVerifyInFlight) return;

    // Never create/restore Prospect over Member
    if (isVerifiedMember()) {
      log('Skipping prospect verification because member state is active.');
      return;
    }

    prospectVerifyInFlight = true;

    try {
      const ts = String(nowTs());

      ssSet(STORAGE_KEYS.prospectSession, '1');
      lsSet(STORAGE_KEYS.prospectPersistTs, ts);
      lsSet(STORAGE_KEYS.prospectLastSource, source || 'unknown');

      log('Prospect verified from source:', source);

      if (!options.skipTrack) {
        track('fl_prospect_verified', {
          source: source || 'unknown',
          page_path: location.pathname
        });
      }

      await applyProspectDiscount({ force: false });
      broadcastProspectStateChanged(source || 'unknown');
    } finally {
      prospectVerifyInFlight = false;
    }
  }

  function getOmnisendCampaignType() {
    try {
      const params = new URLSearchParams(window.location.search);

      const sourceParam = (CONFIG.omnisendCampaignRules && CONFIG.omnisendCampaignRules.sourceParam) || 'utm_source';
      const sourceValue = (CONFIG.omnisendCampaignRules && CONFIG.omnisendCampaignRules.sourceValue) || 'omnisend';
      const campaignParam = (CONFIG.omnisendCampaignRules && CONFIG.omnisendCampaignRules.campaignParam) || 'utm_campaign';

      const source = (params.get(sourceParam) || '').toLowerCase();
      const campaign = (params.get(campaignParam) || '').toLowerCase();

      if (source !== String(sourceValue).toLowerCase() || !campaign) {
        return null;
      }

      if (campaign.includes('_member_')) return 'member';
      if (campaign.includes('_prospect_')) return 'prospect';

      return null;
    } catch (e) {
      return null;
    }
  }

    function hasMemberSessionUrlTrigger() {
    try {
      if (!MEMBER_SESSION_URL_PARAM) return false;
      const params = new URLSearchParams(window.location.search);
      const value = (params.get(MEMBER_SESSION_URL_PARAM) || '').trim();
      return value === MEMBER_SESSION_URL_VALUE;
    } catch (e) {
      return false;
    }
  }

    function hasProspectSessionUrlTrigger() {
    try {
      if (!PROSPECT_SESSION_URL_PARAM) return false;
      const params = new URLSearchParams(window.location.search);
      const value = (params.get(PROSPECT_SESSION_URL_PARAM) || '').trim();
      return value === PROSPECT_SESSION_URL_VALUE;
    } catch (e) {
      return false;
    }
  }

  function classifyOmnisendForm(form) {
    const formId = String(form.id || '').trim();
    const displayType = String(form.displayType || '').toLowerCase();

    const isPopup = displayType === 'popup' || displayType === 'flyout';
    const isEmbedded = displayType === 'embedded';

    if (isPopup) {
      return { countsAsMember: false, reason: 'popup_never_member' };
    }

    if (!isEmbedded) {
      return { countsAsMember: false, reason: 'unsupported_form_type' };
    }

    if (EXCLUDED_EMBEDDED_FORM_IDS.includes(formId)) {
      return { countsAsMember: false, reason: 'excluded_embedded' };
    }

    if (isMemberSignInForm(form)) {
      return { countsAsMember: true, reason: 'member_signin_embedded' };
    }

    return { countsAsMember: false, reason: 'embedded_not_member' };
  }

    function isMemberSignInForm(form) {
    const formId = String((form && form.id) || '').trim();
    return !!formId && MEMBER_SIGNIN_FORM_IDS.includes(formId);
  }

  function isMemberActivationForm(form) {
    const formId = String((form && form.id) || '').trim();
    return !!formId && MEMBER_ACTIVATION_FORM_IDS.includes(formId);
  }

  async function checkMemberActivationFormResultAndActivate(form) {
    const root = getOmnisendFormRoot(form);
    if (!root) {
      log('Could not find Omnisend form root for member activation form:', form && form.id);
      return;
    }

    if (isOmnisendSubscribedState(root)) {
      log('Member activation form returned subscribed state — activating member');
      await markMemberVerified('member_activation_form_subscribed');
      return;
    }

    if (isOmnisendSuccessState(root)) {
      log('Member activation form returned success state — activating member');
      await markMemberVerified('member_activation_form_success');
      return;
    }

    log('Member activation form submit detected, but no success/subscribed state found yet.');
  }

  function cssEscapeSafe(value) {
    try {
      if (window.CSS && typeof window.CSS.escape === 'function') {
        return window.CSS.escape(value);
      }
    } catch (e) {}
    return String(value || '').replace(/[^a-zA-Z0-9\-_]/g, '\\$&');
  }

  function getOmnisendFormRoot(form) {
    const formId = String((form && form.id) || '').trim();
    if (!formId) return null;

    const escapedId = cssEscapeSafe(formId);

    let el = document.getElementById(formId);
    if (el) return el;

    el = document.querySelector('#' + escapedId);
    if (el) return el;

    el = document.querySelector('[id*="' + formId + '"]');
    if (el) return el;

    return null;
  }

  function hasVisibleOmnisendState(root, partialClassName) {
    if (!root) return false;

    const node = root.querySelector('[class*="' + partialClassName + '"]');
    if (!node) return false;

    const cs = window.getComputedStyle(node);
    return cs.display !== 'none' && cs.visibility !== 'hidden' && cs.opacity !== '0';
  }

  function isOmnisendSubscribedState(root) {
    return hasVisibleOmnisendState(root, 'subscribed-sections-container');
  }

  function isOmnisendSuccessState(root) {
    return hasVisibleOmnisendState(root, 'success-sections-container');
  }

  async function checkPopupResultAndRoute(form) {
    const root = getOmnisendFormRoot(form);
    if (!root) {
      log('Could not find Omnisend form root for popup result check:', form && form.id);
      return;
    }

    if (isOmnisendSubscribedState(root)) {
      log('Popup returned subscribed state — activating membership recovery');
      await markMemberVerified('popup_existing_subscriber');
      return;
    }

    if (isOmnisendSuccessState(root)) {
      log('Popup returned success state — activating prospect state');
      await markProspectVerified('popup_success_signup');
      return;
    }

    log('Popup submit detected, but no subscribed/success state found yet.');
  }

  let omnisendSubmitHandledAt = 0;

  function wireOmnisendListener() {
    window.addEventListener('omnisendForms', function (e) {
      const detail = e.detail || {};
      const form = detail.form || {};

      if (detail.type !== 'submit') return;

      const formId = String(form.id || '');
      const displayType = String(form.displayType || '').toLowerCase();
      const formName = String(form.name || '');

      log('Omnisend submit detected:', {
        id: formId,
        name: formName,
        displayType: displayType
      });

      const isPopup = displayType === 'popup' || displayType === 'flyout';

      // Popup special case:
      // - subscribed state => Member
      // - success state => Prospect
      if (isPopup) {
        const now = nowTs();
        if (now - omnisendSubmitHandledAt < 1500) {
          log('Duplicate Omnisend popup submit ignored.');
          return;
        }
        omnisendSubmitHandledAt = now;

        setTimeout(function () {
          checkPopupResultAndRoute(form);
        }, 600);

        return;
      }

      // Membership landing page form:
      // Success or Subscribed should both activate membership
      if (isMemberActivationForm(form)) {
        const now = nowTs();
        if (now - omnisendSubmitHandledAt < 1500) {
          log('Duplicate Omnisend member activation form submit ignored.');
          return;
        }
        omnisendSubmitHandledAt = now;

        setTimeout(function () {
          checkMemberActivationFormResultAndActivate(form);
        }, 600);

        return;
      }

      // Embedded member sign-in forms only
      const classification = classifyOmnisendForm(form);

      if (!classification.countsAsMember) {
        log('Omnisend form excluded from membership:', classification.reason, formId);
        return;
      }

      const now = nowTs();
      if (now - omnisendSubmitHandledAt < 1500) {
        log('Duplicate Omnisend submit ignored.');
        return;
      }
      omnisendSubmitHandledAt = now;

      markMemberVerified('omnisend_' + classification.reason + '_submit');
    });
  }

  function wireMemberVerifiedEvent() {
    window.addEventListener('fl_member_verified', function (e) {
      const source = e && e.detail && e.detail.source ? e.detail.source : 'custom_event';
      markMemberVerified(source);
    });
  }

  async function bootstrapMemberState() {
    const campaignType = getOmnisendCampaignType();
    const hasMemberUrlTrigger = hasMemberSessionUrlTrigger();
    const hasProspectUrlTrigger = hasProspectSessionUrlTrigger();

    // Member always wins
    if (campaignType === 'member') {
      await markMemberVerified('omnisend_member_campaign', { skipTrack: true });
      return;
    }

    if (hasMemberUrlTrigger) {
      await markMemberVerified('member_url_trigger', { skipTrack: true });
      return;
    }

    if (hasProspectUrlTrigger) {
      if (!isVerifiedMember()) {
        await markProspectVerified('prospect_url_trigger', { skipTrack: true });
      }
      return;
    }

    // Prospect campaign can restore Prospect state on new device / cleared cookies
    if (campaignType === 'prospect') {
      if (!isVerifiedMember()) {
        await markProspectVerified('omnisend_prospect_campaign', { skipTrack: true });
      }
      return;
    }

    if (memberPersistValid() && !hasMemberSession()) {
      await markMemberVerified('persisted_member', { skipTrack: true });
      return;
    }

    if (isVerifiedMember()) {
      await applyRelevantMemberDiscounts();
      broadcastMemberStateChanged(lsGet(STORAGE_KEYS.memberLastSource) || 'existing_member');
      return;
    }

if (prospectPersistValid() && !hasProspectSession()) {
  ssSet(STORAGE_KEYS.prospectSession, '1');

  log('Restoring existing prospect session (no timestamp reset)');

  await applyProspectDiscount({ force: false });
  broadcastProspectStateChanged(lsGet(STORAGE_KEYS.prospectLastSource) || 'existing_prospect');

  return;
}

    if (isVerifiedProspect()) {
      await applyProspectDiscount({ force: false });
      broadcastProspectStateChanged(lsGet(STORAGE_KEYS.prospectLastSource) || 'existing_prospect');
    }
  }

  window.FLMember = {
    isVerifiedMember: isVerifiedMember,
    memberPersistValid: memberPersistValid,
    hasKnownMemberHistory: hasKnownMemberHistory,
    isExpiredKnownMember: isExpiredKnownMember,

    isVerifiedProspect: isVerifiedProspect,
    prospectPersistValid: prospectPersistValid,
    applyProspectDiscount: applyProspectDiscount,
    markProspectVerified: markProspectVerified,
    clearProspectState: clearProspectState,

    markMemberVerified: markMemberVerified,
    applyRelevantMemberDiscounts: applyRelevantMemberDiscounts,
    forceApplyCodes: forceApplyCodes,
    getRenderedOfferCodes: getRenderedOfferCodes,
    getAllActiveMemberCodes: getAllActiveMemberCodes
  };

  document.addEventListener('DOMContentLoaded', function () {
    wireOmnisendListener();
    wireMemberVerifiedEvent();
    bootstrapMemberState();
  });
})();