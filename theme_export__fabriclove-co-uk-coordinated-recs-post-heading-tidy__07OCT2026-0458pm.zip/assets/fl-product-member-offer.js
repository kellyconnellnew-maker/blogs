/* ===========================
   Fabric Love - Product Member Offer
   - Display only for active members
   - Expired known members get Safari-safe member reactivation flow
   - Uses generic FLModal shell
   - No signup logic for new customers
   =========================== */

(function () {
  const MEMBER_SIGNIN_OMNISEND_ID = 'omnisend-embedded-v2-69bab67dd052b6290405402a';

  function norm(s) {
    return (s || '').toString().trim();
  }

  function normUpper(s) {
    return norm(s).toUpperCase();
  }

  function parseTags(tagString) {
    return (tagString || '')
      .split('|')
      .map(function (t) { return norm(t); })
      .filter(Boolean);
  }

  function hasMemberOfferTag(tags, code) {
    const target = ('member_offer:' + normUpper(code)).toLowerCase();
    return tags.some(function (t) {
      return t.toLowerCase() === target;
    });
  }

  const OFFERS = [
        {
         key: "SALE25",
      enabled: false,
      memberSale: true,
      code: "SALE25",
      appliedText: "Your member price is active ✓",
      appliedLink: "/collections/early-access-member-sale",
      appliedLinkText: "Early Access Summer Sale: 25% Off",
      memberAreaImageDesktop: "https://cdn.shopify.com/s/files/1/0742/2037/files/ChatGPT_Image_Jul_10_2026_05_11_31_PM-56.jpg?v=1783700898",
      memberAreaImageMobile: "https://cdn.shopify.com/s/files/1/0742/2037/files/ChatGPT_Image_Jul_10_2026_05_11_31_PM-56.jpg?v=1783700898",
      match: {
        vendor: [],
        productType: [],
        tags: ["member_offer:SALE25"]
      }
    },
    {
         key: "SALE50",
      enabled: false,
      memberSale: true,
      code: "SALE50",
      appliedText: "Your member price is active ✓",
      appliedLink: "/collections/early-access-member-sale",
      appliedLinkText: "Early Access Summer Sale: 50% Off",
      memberAreaImageDesktop: "https://cdn.shopify.com/s/files/1/0742/2037/files/ChatGPT_Image_Jul_10_2026_05_11_31_PM-56.jpg?v=1783700898",
      memberAreaImageMobile: "https://cdn.shopify.com/s/files/1/0742/2037/files/ChatGPT_Image_Jul_10_2026_05_11_31_PM-56.jpg?v=1783700898",
      match: {
        vendor: [],
        productType: [],
        tags: ["member_offer:SALE50"]
      }
    },
       {
      key: "SALE10",
      enabled: false,
      memberSale: true,
      code: "LOVE10",
      appliedText: "Your member price is active ✓",
      appliedLink: "/collections/early-access-member-sale",
      appliedLinkText: "Early Access Summer Sale: 10% Off",
      memberAreaImageDesktop: "https://cdn.shopify.com/s/files/1/0742/2037/files/ChatGPT_Image_Jul_10_2026_05_11_31_PM-56.jpg?v=1783700898",
      memberAreaImageMobile: "https://cdn.shopify.com/s/files/1/0742/2037/files/ChatGPT_Image_Jul_10_2026_05_11_31_PM-56.jpg?v=1783700898",
      match: {
        vendor: [],
        productType: [],
        tags: ["member_offer:SALE10"]
      }
    },
    {
         key: "SALE15",
      enabled: false,
      memberSale: true,
      code: "LOVE15",
      appliedText: "Your member price is active ✓",
      appliedLink: "/collections/early-access-member-sale",
      appliedLinkText: "Early Access Summer Sale: 15% Off",
      memberAreaImageDesktop: "https://cdn.shopify.com/s/files/1/0742/2037/files/ChatGPT_Image_Jul_10_2026_05_11_31_PM-56.jpg?v=1783700898",
      memberAreaImageMobile: "https://cdn.shopify.com/s/files/1/0742/2037/files/ChatGPT_Image_Jul_10_2026_05_11_31_PM-56.jpg?v=1783700898",
      match: {
        vendor: [],
        productType: [],
        tags: ["member_offer:SALE15"]
      }
    },
            {
      key: "POLY544",
      enabled: false,
      code: "POLY544",
      appliedText: "Your member price is active ✓",
      appliedLink: "/collections/printed-polycottons",
      appliedLinkText: "Buy 4 Polycotton Prints, Get 5th Free",
      memberAreaImageDesktop: "https://cdn.shopify.com/s/files/1/0742/2037/files/ChatGPT_Image_Jul_10_2026_05_11_31_PM-56.jpg?v=1783700898",
      memberAreaImageMobile: "https://cdn.shopify.com/s/files/1/0742/2037/files/ChatGPT_Image_Jul_10_2026_05_11_31_PM-56.jpg?v=1783700898",
      match: {
        vendor: [],
        productType: ["Polycotton"],
        tags: []
      }
    },
    {
      key: "HALLOWEEN10",
      enabled: true,
      code: "LOVE10",
      appliedText: "Your member price is active ✓",
      appliedLink: "/collections/halloween-fabrics",
      appliedLinkText: "10% off Halloween fabrics",
      memberAreaImageDesktop: "https://cdn.shopify.com/s/files/1/0742/2037/files/pumpkin-89.jpg?v=1791382889",
      memberAreaImageMobile: "https://cdn.shopify.com/s/files/1/0742/2037/files/pumpkin-89.jpg?v=1791382889",
      match: {
        vendor: [],
        productType: [],
        tags: ["member_offer:HALLOWEEN10"]
      }
    },
        {
      key: "INTRO10",
      enabled: false,
      code: "LOVE10",
      appliedText: "Your member price is active ✓",
      appliedLink: "/collections/intro10",
      appliedLinkText: "10% off selected new fabrics",
      memberAreaImageDesktop: "https://cdn.shopify.com/s/files/1/0742/2037/files/New_fabrics_collection_image.jpg?v=1790691081",
      memberAreaImageMobile: "https://cdn.shopify.com/s/files/1/0742/2037/files/New_fabrics_collection_image.jpg?v=1790691081",
      match: {
        vendor: [],
        productType: [],
        tags: ["member_offer:INTRO10"]
      }
    },
    {
      key: "VISCOSE10",
      enabled: false,
      code: "LOVE10",
      appliedText: "Your member price is active ✓",
      appliedLink: "/collections/viscose-fabric",
      appliedLinkText: "10% off all viscose fabrics",
      memberAreaImageDesktop: "https://cdn.shopify.com/s/files/1/0742/2037/files/Copy_of_Rose_Hubble_Offer.png?v=1779372545",
      memberAreaImageMobile: "https://cdn.shopify.com/s/files/1/0742/2037/files/Copy_of_Rose_Hubble_Offer.png?v=1779372545",
      match: {
        vendor: [],
        productType: ["Viscose","Lyocell Viscose","Viscose Challis","Viscose Lawn","Viscose Jersey","Viscose Sateen"],
        tags: []
      }
    },
    {
      key: "HUBBLE10",
      enabled: true,
      code: "LOVE10",
      appliedText: "Your member price is active ✓",
      appliedLink: "/collections/rose-and-hubble-fabric",
      appliedLinkText: "10% Off all Rose & Hubble fabrics",
      memberAreaImageDesktop: "https://cdn.shopify.com/s/files/1/0742/2037/files/Rose_Hubble_Offer_Background.png?v=1776090625",
      memberAreaImageMobile: "https://cdn.shopify.com/s/files/1/0742/2037/files/Rose_Hubble_Offer_Background.png?v=1776090625",
      match: {
        vendor: ["Rose & Hubble"],
        productType: [],
        tags: []
      }
    },
    {
      key: "BATIK10",
      enabled: true,
      code: "LOVE10",
      appliedText: "Your member price is active ✓",
      appliedLink: "/collections/batik-fabric",
      appliedLinkText: "10% Off all Batik Cottons",
      memberAreaImageDesktop: "https://cdn.shopify.com/s/files/1/0742/2037/files/Batik_Offer_Background.png?v=1776090785",
      memberAreaImageMobile: "https://cdn.shopify.com/s/files/1/0742/2037/files/Batik_Offer_Background.png?v=1776090785",
      match: {
        vendor: [],
        productType: [],
        tags: ["Batik"]
      }
    },
    {
      key: "PERCALE10",
      enabled: false,
      code: "LOVE10",
      appliedText: "Your member price is active ✓",
      appliedLink: "/collections/cotton-percales-for-dressmaking",
      appliedLinkText: "10% Off Cotton Percale - Ends Soon",
      memberAreaImageDesktop: "https://cdn.shopify.com/s/files/1/0742/2037/files/Percale_offer.jpg?v=1776788422",
      memberAreaImageMobile: "https://cdn.shopify.com/s/files/1/0742/2037/files/Percale_offer.jpg?v=1776788422",
      match: {
        vendor: [],
        productType: ["Cotton Percale"],
        tags: []
      }
    },
    {
      key: "QUILT5",
      enabled: true,
      code: "QUILT5",
      appliedText: "Your £5 Off member offer is active ✓",
      appliedLink: "/collections/quilting-fabrics",
      appliedLinkText: "Spend £40 on quilting fabrics, get £5 off",
      memberAreaImageDesktop: "https://cdn.shopify.com/s/files/1/0742/2037/files/Quilting_Offer_Background.png?v=1776090626",
      memberAreaImageMobile: "https://cdn.shopify.com/s/files/1/0742/2037/files/Quilting_Offer_Background.png?v=1776090626",
      match: {
        vendor: [],
        productType: ["Quilting Cotton"],
        tags: []
      }
    },
      {
      key: "STUDIO10",
      enabled: true,
      code: "LOVE10",
      appliedText: "Your member price is active ✓",
      appliedLink: "/collections/e-studio-cottons",
      appliedLinkText: "10% Off E Studio cottons",
      memberAreaImageDesktop: "https://cdn.shopify.com/s/files/1/0742/2037/files/Little_Johnny_Offer_Background.png?v=1776090625",
      memberAreaImageMobile: "https://cdn.shopify.com/s/files/1/0742/2037/files/Little_Johnny_Offer_Background.png?v=1776090625",
      match: {
        vendor: [],
        productType: [],
        tags: ["member_offer:e_studio"]
      }
    },
    {
      key: "JOHNNY10",
      enabled: true,
      code: "LOVE10",
      appliedText: "Your member price is active ✓",
      appliedLink: "/collections/little-johnny-cotton-fabric",
      appliedLinkText: "10% Off Little Johnny cottons",
      memberAreaImageDesktop: "https://cdn.shopify.com/s/files/1/0742/2037/files/Little_Johnny_Offer_Background.png?v=1776090625",
      memberAreaImageMobile: "https://cdn.shopify.com/s/files/1/0742/2037/files/Little_Johnny_Offer_Background.png?v=1776090625",
      match: {
        vendor: [],
        productType: [],
        tags: ["member_offer:JOHNNY10"]
      }
    },
    {
      key: "PLAINPOP15",
      enabled: true,
      code: "LOVE15",
      appliedText: "Your member price is active ✓",
      appliedLink: "/collections/plain-cotton-poplin_wide",
      appliedLinkText: "15% Off Plain Wide Cotton Poplins",
      memberAreaImageDesktop: "https://cdn.shopify.com/s/files/1/0742/2037/files/Plain_Fabrics_Offer_Background.png?v=1776091163",
      memberAreaImageMobile: "https://cdn.shopify.com/s/files/1/0742/2037/files/Plain_Fabrics_Offer_Background.png?v=1776091163",
      match: {
        vendor: [],
        productType: [],
        tags: ["member_offer:LOVE15"]
      }
    },
    {
      key: "PLAINPOLY15",
      enabled: true,
      code: "LOVE15",
      appliedText: "Your member price is active ✓",
      appliedLink: "/collections/plain-polycotton-fabric",
      appliedLinkText: "15% Off Plain Polycottons",
      memberAreaImageDesktop: "https://cdn.shopify.com/s/files/1/0742/2037/files/Plain_Fabrics_Offer_Background.png?v=1776091163",
      memberAreaImageMobile: "https://cdn.shopify.com/s/files/1/0742/2037/files/Plain_Fabrics_Offer_Background.png?v=1776091163",
      match: {
        vendor: [],
        productType: ["Plain Polycotton"],
        tags: []
      }
    }
  ];

  window.FL_OFFERS = OFFERS;

function isEligible(offer, tags, vendor, productType) {
  const vendors = (offer.match && offer.match.vendor) || [];
  if (vendors.length && vendors.some(function (v) { return v === vendor; })) {
    return true;
  }

  const types = (offer.match && offer.match.productType) || [];
  if (types.length && types.some(function (t) { return t === productType; })) {
    return true;
  }

  const matchTags = (offer.match && offer.match.tags) || [];
  if (
    matchTags.length &&
    matchTags.some(function (matchTag) {
      return tags.some(function (productTag) {
        return normUpper(productTag) === normUpper(matchTag);
      });
    })
  ) {
    return true;
  }

  return false;
}

  function renderOfferHTML(offer) {
    return `
      <div class="fl-offer-root">
        <div
          class="fl-offer-container fl-offer-container--applied"
          data-fl-member-offer
          data-offer-key="${offer.key}"
          data-discount-code="${offer.code}"
        >
          <div class="fl-offer-image">
            <img
              src="https://cdn.shopify.com/s/files/1/0742/2037/files/member_offer_logo.png?v=1771243094"
              alt="Member offer"
            >
          </div>

          <div class="fl-offer-text">
            <div class="fl-offer-applied is-on">
              <div class="fl-offer-applied-main">${offer.appliedText}</div>
              <a href="${offer.appliedLink}" class="fl-offer-applied-sub fl-offer-applied-link">
                ${offer.appliedLinkText}
              </a>
            </div>
          </div>
        </div>
      </div>
    `.trim();
  }

  function renderReactivationHTML() {
    return `
      <div class="fl-offer-root">
        <div class="fl-offer-container fl-offer-container--reactivate" data-fl-member-reactivate>
          <div class="fl-offer-image">
            <img
              src="https://cdn.shopify.com/s/files/1/0742/2037/files/member_offer_logo.png?v=1771243094"
              alt="Member prices"
            >
          </div>

          <div class="fl-offer-text">
            <a href="#" class="fl-offer-link" data-fl-member-reactivate-toggle>
              View your member prices
            </a>
          </div>

          <div class="fl-offer-form" data-fl-member-signin-form>
            <div id="${MEMBER_SIGNIN_OMNISEND_ID}"></div>
          </div>
        </div>
      </div>
    `.trim();
  }

  function clearMount(mount) {
    mount.innerHTML = '';
    mount.style.display = 'none';
  }

  function getSignInFormWrap(mount) {
    return mount.querySelector('[data-fl-member-signin-form]');
  }

  function getOmnisendHolder(formWrap) {
    if (!formWrap) return null;
    return formWrap.querySelector('#' + MEMBER_SIGNIN_OMNISEND_ID);
  }

  function isEmbedReady(formWrap) {
    const holder = getOmnisendHolder(formWrap);
    if (!holder) return false;
    return (holder.children && holder.children.length > 0) || (holder.childNodes && holder.childNodes.length > 0);
  }

  function waitForEmbedReady(formWrap, timeoutMs) {
    timeoutMs = typeof timeoutMs === 'number' ? timeoutMs : 12000;

    return new Promise(function (resolve) {
      if (!formWrap) return resolve(false);
      if (formWrap.__flOmniReady === true) return resolve(true);

      if (isEmbedReady(formWrap)) {
        formWrap.__flOmniReady = true;
        return resolve(true);
      }

      const holder = getOmnisendHolder(formWrap);
      if (!holder) return resolve(false);

      let done = false;
      const start = Date.now();

      function finish(ok) {
        if (done) return;
        done = true;
        try { obs && obs.disconnect(); } catch (e) {}
        formWrap.__flOmniReady = !!ok;
        resolve(!!ok);
      }

      let obs = null;
      try {
        obs = new MutationObserver(function () {
          if (isEmbedReady(formWrap)) finish(true);
          if (Date.now() - start > timeoutMs) finish(false);
        });
        obs.observe(holder, { childList: true, subtree: true });
      } catch (e) {
        const t = setInterval(function () {
          if (isEmbedReady(formWrap)) { clearInterval(t); finish(true); }
          if (Date.now() - start > timeoutMs) { clearInterval(t); finish(false); }
        }, 150);
      }

      setTimeout(function () {
        finish(isEmbedReady(formWrap));
      }, timeoutMs);
    });
  }

  function hasOmnisendReachedSuccessWithForm(formWrapEl) {
    if (!formWrapEl) return false;

    const success = formWrapEl.querySelector('[class*="success-sections-container"]');
    const subscribed = formWrapEl.querySelector('[class*="subscribed-sections-container"]');

    function isShown(el) {
      if (!el) return false;
      const cs = window.getComputedStyle(el);
      return cs.display !== 'none' && cs.visibility !== 'hidden' && cs.opacity !== '0';
    }

    return isShown(success) || isShown(subscribed);
  }

  function rememberOriginalParent(node) {
    if (!node || node.__flOriginalParent) return;
    node.__flOriginalParent = node.parentElement;
    node.__flOriginalNext = node.nextElementSibling;
  }

  function restoreToOriginalPlace(node) {
    if (!node || !node.__flOriginalParent) return;
    const parent = node.__flOriginalParent;
    const next = node.__flOriginalNext;
    if (next && next.parentElement === parent) parent.insertBefore(node, next);
    else parent.appendChild(node);
  }

  let pollTimer = null;
  let activeFormWrap = null;

  function stopPolling() {
    if (pollTimer) {
      clearInterval(pollTimer);
      pollTimer = null;
    }
  }

  function closeReactivationModal() {
    stopPolling();

    if (activeFormWrap) {
      restoreToOriginalPlace(activeFormWrap);
      activeFormWrap.classList.remove('is-open');
      activeFormWrap = null;
    }

    if (window.FLModal && typeof window.FLModal.close === 'function') {
      window.FLModal.close();
    }
  }

  async function handleIfSuccessNow() {
    if (!activeFormWrap) return;
    if (!hasOmnisendReachedSuccessWithForm(activeFormWrap)) return;
    if (activeFormWrap.__flSuccessHandled) return;

    activeFormWrap.__flSuccessHandled = true;
    stopPolling();

    if (
      window.FLMember &&
      typeof window.FLMember.markMemberVerified === 'function'
    ) {
      await window.FLMember.markMemberVerified('member_signin_submit');
    }

    closeReactivationModal();
  }

  function startPolling() {
    if (pollTimer) return;

    const start = Date.now();
    pollTimer = setInterval(async function () {
      if (Date.now() - start > 30000) {
        stopPolling();
        return;
      }
      await handleIfSuccessNow();
    }, 250);
  }

  async function openReactivationModal(mount) {
    if (!window.FLModal || typeof window.FLModal.openWithNode !== 'function') return;

    const formWrap = getSignInFormWrap(mount);
    if (!formWrap) return;

    const ready = await waitForEmbedReady(formWrap, 12000);

    if (!ready) {
      if (window.FLModal && typeof window.FLModal.openWithHTML === 'function') {
        window.FLModal.openWithHTML('<div class="fl-offer-loading">The sign-in form is taking a moment to load. Please refresh and try again.</div>');
      }
      return;
    }

    activeFormWrap = formWrap;
    activeFormWrap.__flSuccessHandled = false;

    rememberOriginalParent(formWrap);
    formWrap.classList.add('is-open');

    window.FLModal.openWithNode(formWrap);

    requestAnimationFrame(function () {
      try { window.dispatchEvent(new Event('resize')); } catch (e) {}
    });
    setTimeout(function () {
      try { window.dispatchEvent(new Event('resize')); } catch (e) {}
    }, 150);

    startPolling();
  }

  function wireReactivation(mount) {
    const link = mount.querySelector('[data-fl-member-reactivate-toggle]');
    if (!link) return;

    waitForEmbedReady(getSignInFormWrap(mount), 12000);

    link.addEventListener('click', function (e) {
      e.preventDefault();
      openReactivationModal(mount);
    });
  }

  async function renderOffers() {
    const mount = document.querySelector('[data-fl-member-offers]');
    if (!mount) return;

    const isMember = !!(
      window.FLMember &&
      typeof window.FLMember.isVerifiedMember === 'function' &&
      window.FLMember.isVerifiedMember()
    );

    const isExpiredKnownMember = !!(
      window.FLMember &&
      typeof window.FLMember.isExpiredKnownMember === 'function' &&
      window.FLMember.isExpiredKnownMember()
    );

    if (!isMember && !isExpiredKnownMember) {
      clearMount(mount);
      return;
    }

    if (isExpiredKnownMember && !isMember) {
      mount.innerHTML = renderReactivationHTML();
      mount.style.display = 'block';
      wireReactivation(mount);
      return;
    }

    const tags = parseTags(mount.getAttribute('data-tags') || '');
    const vendor = norm(mount.getAttribute('data-vendor') || '');
    const productType = norm(mount.getAttribute('data-product-type') || '');

    const eligibleOffers = OFFERS
      .filter(function (offer) {
        return offer && offer.enabled && offer.code;
      })
      .filter(function (offer) {
        return isEligible(offer, tags, vendor, productType);
      });

    if (!eligibleOffers.length) {
      clearMount(mount);
      return;
    }

    mount.innerHTML = eligibleOffers.map(renderOfferHTML).join('\n');
    mount.style.display = 'block';

    if (
      window.FLMember &&
      typeof window.FLMember.forceApplyCodes === 'function'
    ) {
      await window.FLMember.forceApplyCodes(
        eligibleOffers.map(function (offer) {
          return offer.code;
        })
      );
    }
  }

  document.addEventListener('DOMContentLoaded', function () {
    renderOffers();
  });

  window.addEventListener('fl_member_state_changed', function () {
    renderOffers();
  });

  document.addEventListener('click', function (e) {
    if (e.target.closest('[data-fl-modal-close]')) {
      closeReactivationModal();
    }
  });

  document.addEventListener('keydown', function (e) {
    const modal = document.getElementById('fl-modal');
    if (e.key === 'Escape' && modal && modal.classList.contains('is-open')) {
      closeReactivationModal();
    }
  });
})();