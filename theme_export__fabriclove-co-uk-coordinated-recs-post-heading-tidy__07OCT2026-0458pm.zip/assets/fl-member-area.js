/* ===========================
   Fabric Love - Member Area
   - Renders active member offers from window.FL_OFFERS
   - Uses <picture> for responsive desktop/mobile images
   - Overlays offer text block and Shop Now button on image
   - Can optionally restrict visibility to verified members
   =========================== */

(function () {
  // Display-only configuration for the single generic member-sale card.
  // This file never changes offer eligibility or applies discount codes.
  var MEMBER_SALE_CARD = {
    key: 'MEMBER_SALE',
    appliedLink: '/collections/early-access-member-sale',
    appliedLinkText: 'Members Early Access Summer Sale - Up to 50% Off',
    memberAreaImageDesktop: 'https://cdn.shopify.com/s/files/1/0742/2037/files/Sale.png?v=1785837555',
    memberAreaImageMobile: 'https://cdn.shopify.com/s/files/1/0742/2037/files/Sale.png?v=1785837555'
  };

  function escapeHtml(str) {
    return String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function isVerifiedMember() {
    return !!(
      window.FLMember &&
      typeof window.FLMember.isVerifiedMember === 'function' &&
      window.FLMember.isVerifiedMember()
    );
  }

  function getOffers() {
    if (!Array.isArray(window.FL_OFFERS)) return [];

    var offers = window.FL_OFFERS.filter(function (offer) {
      return !!(
        offer &&
        offer.enabled &&
        offer.appliedLink &&
        offer.appliedLinkText &&
        offer.memberAreaImageDesktop
      );
    });

    var hasActiveSaleOffer = offers.some(function (offer) {
      return offer.memberSale === true;
    });

    if (!hasActiveSaleOffer) {
      return offers;
    }

    var saleCardAdded = false;

    return offers.reduce(function (cards, offer) {
      if (offer.memberSale !== true) {
        cards.push(offer);
        return cards;
      }

      // Replace every offer belonging to the active sale with one generic card.
      if (!saleCardAdded) {
        cards.push({
          key: MEMBER_SALE_CARD.key,
          appliedLink: MEMBER_SALE_CARD.appliedLink,
          appliedLinkText: MEMBER_SALE_CARD.appliedLinkText,
          memberAreaImageDesktop: MEMBER_SALE_CARD.memberAreaImageDesktop,
          memberAreaImageMobile: MEMBER_SALE_CARD.memberAreaImageMobile
        });
        saleCardAdded = true;
      }

      return cards;
    }, []);
  }

  function renderOfferCard(offer) {
    var desktopImage = offer.memberAreaImageDesktop || '';
    var mobileImage = offer.memberAreaImageMobile || desktopImage;
    var offerText = offer.appliedLinkText || '';
    var link = offer.appliedLink || '#';
    var key = offer.key || '';

    return `
      <article class="fl-member-area-card" data-offer-key="${escapeHtml(key)}">
        <a class="fl-member-area-card__link" href="${escapeHtml(link)}">
          <div class="fl-member-area-card__media">
            <picture class="fl-member-area-card__picture">
              <source
                media="(max-width: 767px)"
                srcset="${escapeHtml(mobileImage)}"
              >
              <img
                class="fl-member-area-card__image"
                src="${escapeHtml(desktopImage)}"
                alt="${escapeHtml(offerText)}"
                loading="lazy"
              >
            </picture>

            <div class="fl-member-area-card__overlay">
              <div class="fl-member-area-card__text-block">
                ${escapeHtml(offerText)}
              </div>

              <span class="fl-member-area-card__button">
                Shop Now
              </span>
            </div>
          </div>
        </a>
      </article>
    `.trim();
  }

  function renderMemberArea() {
    var mounts = document.querySelectorAll('[data-fl-member-area]');
    if (!mounts.length) return;

    var offers = getOffers();

    mounts.forEach(function (mount) {
      var membersOnly = mount.getAttribute('data-members-only') === 'true';

      if (membersOnly && !isVerifiedMember()) {
        mount.innerHTML = '';
        mount.style.display = 'none';
        return;
      }

      if (!offers.length) {
        mount.innerHTML = '';
        mount.style.display = 'none';
        return;
      }

      mount.innerHTML = `
        <div class="fl-member-area-grid">
          ${offers.map(renderOfferCard).join('\n')}
        </div>
      `.trim();

      mount.style.display = 'block';
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    renderMemberArea();
  });

  window.addEventListener('fl_member_state_changed', function () {
    renderMemberArea();
  });
})();
