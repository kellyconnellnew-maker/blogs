/* ===========================
   Fabric Love - Generic Modal Shell
   - No membership logic
   - No Omnisend success logic
   - Reusable from nav, homepage, PDP etc
   =========================== */

(function () {
  function getModal() {
    return document.getElementById('fl-modal');
  }

  function getModalContent() {
    return document.getElementById('fl-modal-content');
  }

  function openModalWithNode(node) {
    const modal = getModal();
    const content = getModalContent();
    if (!modal || !content || !node) return;

    content.innerHTML = '';
    content.appendChild(node);

    modal.classList.add('is-open');
    modal.setAttribute('aria-hidden', 'false');
    document.body.classList.add('fl-modal-open');
  }

  function openModalWithHTML(html) {
    const modal = getModal();
    const content = getModalContent();
    if (!modal || !content) return;

    content.innerHTML = html || '';
    modal.classList.add('is-open');
    modal.setAttribute('aria-hidden', 'false');
    document.body.classList.add('fl-modal-open');
  }

  function closeModal() {
    const modal = getModal();
    const content = getModalContent();
    if (!modal || !content) return;

    content.innerHTML = '';
    modal.classList.remove('is-open');
    modal.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('fl-modal-open');
  }

  function wireCloseEvents() {
    const modal = getModal();
    if (!modal || modal.__flWired) return;
    modal.__flWired = true;

    modal.addEventListener('click', function (e) {
      if (e.target.closest('[data-fl-modal-close]')) {
        closeModal();
      }
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && modal.classList.contains('is-open')) {
        closeModal();
      }
    });
  }

  window.FLModal = {
    openWithNode: openModalWithNode,
    openWithHTML: openModalWithHTML,
    close: closeModal
  };

  document.addEventListener('DOMContentLoaded', wireCloseEvents);
})();

