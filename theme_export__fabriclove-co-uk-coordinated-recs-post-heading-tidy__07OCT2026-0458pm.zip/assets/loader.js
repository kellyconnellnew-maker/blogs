(function(){

  //function to load script
  //url is the url containing the script
  //callback is the function to execute after the script is loaded
  var loadScript = function(url, callback){
 
    var script = document.createElement("script");
    script.type = "text/javascript";

    //internet explorer
    if (script.readyState){ 
      script.onreadystatechange = function(){
        if (script.readyState == "loaded" || script.readyState == "complete"){
          script.onreadystatechange = null;
          callback();
        }
      };
    }
    //other browsers
    else {
      script.onload = function(){
        callback();
      };
    }

    script.src = url;
    //append to the head tag the script
    document.getElementsByTagName("head")[0].appendChild(script);
    
  };

  //code that I want to execute
  var myCode = function($){
      if(meta.page.pageType=='product'){
        if($("#myRange").length > 0 && $("#demo").length > 0) {
          var slider = document.getElementById("myRange");
          var output = document.getElementById("demo");
          output.innerHTML = slider.value;
          slider.oninput = function() {
            output.innerHTML = this.value;
          }
        }
        $(document).on('touchmove , mousemove','#myRange',function(){
          var newQuantity = $(document).find('#demo').text();
          if( newQuantity >= 100){
            var newQty = parseFloat(newQuantity)/100;
            $('.slQtylength').text(newQty.toFixed(2));
            $('.qtyunit').text('m');
          }else{
            var newQty = parseInt(newQuantity);
            $('.slQtylength').text(newQty);
            $('.qtyunit').text('cm');
          }
          $('.js-qty__num').val(parseInt(newQuantity/25));
        });
      }
      let total_char = 0;
      if(meta.page.pageType=='collection'){
        var fullStr = $(".text-transform").html();
        var splitString = getWordStr(fullStr);
        var __next_text = fullStr.substring(splitString.length);
        
        var finalStr = splitString + '<span class="temp_box">....</span><span class="hide-next-text">'+__next_text+'</span>';
        $(".text-transform").html(finalStr);
        $(".text-transform").after('<div align="center" class="show-more-less"><a href="javascript:;" class="show_hide_trigger">Show more</a></div>');
        $(".text-transform").show();
        $(".show_hide_trigger").click(function(e) {
            if($('.hide-next-text').is(':hidden')){
              $(".temp_box").hide();
              $(".hide-next-text").show();
              $(".show_hide_trigger").html("Show less");
            } else {
              $(".temp_box").show();
              $(".hide-next-text").hide();
              $(".show_hide_trigger").html("Show more");
            }
        });
      }
    
      function getWordStr(str) {
        return str.split(/\s+/).slice(0, 10).join(" ");
      }
  };

  //if we already have jQuery we simply execute our function
  //if jQuery is undefined we load the script using noConflict
  if (typeof jQuery === 'undefined'){
    loadScript('//code.jquery.com/jquery-1.12.4.js', function(){
      jQuery = jQuery.noConflict(true);
      myCode(jQuery);
    });
  } else {
    myCode(jQuery);
  }

})();